package com.example.practical

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
